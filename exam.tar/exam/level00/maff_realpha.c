
#include <unistd.h>

int		main(void)
{
	write(1, "zYxWuTsRqPoNmLkJiGfEdCbA\n", 25);
	return (0);
}
