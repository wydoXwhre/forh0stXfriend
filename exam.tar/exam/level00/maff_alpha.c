
************************************************************
#include <unistd.h>

int		main(void)
{
	write(1, "aBcDeFgIjKlMnOpQrStUwXyZ\n", 25);
	return (0);
}
