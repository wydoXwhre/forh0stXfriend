
#include <unistd.h>

int 		main(void)

{
	write(1,"a\n", 1 );
	return(0);
}
